import streamlit as st
import pandas as pd
import numpy as np
import joblib
import altair as alt
import base64
from pathlib import Path

# =========================================================
# 1. Load trained model + metadata
# =========================================================
@st.cache_resource
def load_artifacts():
    return joblib.load("churn_xgb_pipeline.pkl")

artifacts = load_artifacts()
model = artifacts["model"]
label_encoder = artifacts["label_encoder"]
churn_threshold = artifacts["churn_threshold"]
churn_idx = artifacts["churn_class_idx"]
feature_names = artifacts["feature_names"]

st.set_page_config(page_title="Customer Churn Prediction", layout="wide")

# =========================================================
# PREMIUM BACKGROUND THEME (image) + FIXED DARK UI
# =========================================================
def _img_to_base64(img_path: str) -> str:
    p = Path(img_path)
    if not p.exists():
        return ""
    return base64.b64encode(p.read_bytes()).decode()

# Use your image name here
bg_b64 = _img_to_base64("Churn_theme.jpg")

st.markdown(
    f"""
    <style>
    /* -------- Remove Streamlit top header bar + footer -------- */
    [data-testid="stHeader"] {{
        display: none !important;
    }}
    [data-testid="stToolbar"] {{
        display: none !important;
    }}
    #MainMenu {{
        visibility: hidden;
    }}
    footer {{
        visibility: hidden;
    }}
    .block-container {{
        padding-top: 1.3rem !important;
        padding-bottom: 2rem !important;
    }}

    /* -------- App background (image + overlay) -------- */
    .stApp {{
        background: #0b0f1a;
        color: #e5e7eb;
        font-family: "Segoe UI", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        {"background-image: url('data:image/jpeg;base64," + bg_b64 + "');" if bg_b64 else ""}
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
    }}

    .stApp::before {{
        content: "";
        position: fixed;
        inset: 0;
        background: linear-gradient(
            135deg,
            rgba(11, 15, 26, 0.78) 0%,
            rgba(26, 8, 46, 0.62) 40%,
            rgba(11, 15, 26, 0.82) 100%
        );
        pointer-events: none;
        z-index: 0;
    }}

    section.main > div {{
        position: relative;
        z-index: 1;
    }}
    [data-testid="stSidebar"] {{
        position: relative;
        z-index: 2;
    }}

    /* -------- Typography -------- */
    h1, h2, h3, h4, label, p, div, span {{
        color: #e5e7eb !important;
    }}
    h1 {{
        font-weight: 900 !important;
        letter-spacing: 0.04em;
        margin-bottom: 0.35rem;
        text-shadow: 0 10px 30px rgba(0,0,0,0.55);
    }}

    /* -------- Glass cards -------- */
    .metric-card {{
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 18px;
        padding: 1.05rem 1.25rem;
        box-shadow: 0 18px 45px rgba(0,0,0,0.45);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }}

    /* -------- Sidebar (glass) -------- */
    [data-testid="stSidebar"] {{
        background: linear-gradient(
            180deg,
            rgba(255,255,255,0.06) 0%,
            rgba(255,255,255,0.03) 100%
        ) !important;
        border-right: 1px solid rgba(255,255,255,0.12);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
    }}

    /* -------- Buttons -------- */
    .stButton>button {{
        border-radius: 999px;
        padding: 0.55rem 1.65rem;
        border: 1px solid rgba(255,255,255,0.18);
        background: linear-gradient(135deg, #a855f7, #3b82f6);
        color: #ffffff !important;
        font-weight: 750;
        box-shadow: 0 14px 35px rgba(0,0,0,0.35);
        transition: transform 120ms ease, box-shadow 120ms ease, filter 120ms ease;
    }}

    /* ======================================================
       FIX: Number input (BaseWeb)
       ====================================================== */
    [data-testid="stNumberInput"] div[data-baseweb="input"] {{
        background: rgba(255,255,255,0.08) !important;
        border: 1px solid rgba(255,255,255,0.14) !important;
        border-radius: 14px !important;
        box-shadow: none !important;
    }}
    [data-testid="stNumberInput"] div[data-baseweb="input"] input {{
        background: transparent !important;
        color: #e5e7eb !important;
        -webkit-text-fill-color: #e5e7eb !important;
    }}
    [data-testid="stNumberInput"] div[data-baseweb="input"] > div {{
        background: rgba(255,255,255,0.10) !important;
        border-left: 1px solid rgba(255,255,255,0.12) !important;
        border-radius: 0 14px 14px 0 !important;
    }}

    /* ======================================================
       FIX: Selectbox + dropdown
       ====================================================== */
    div[data-baseweb="select"] > div {{
        background: rgba(255,255,255,0.08) !important;
        border: 1px solid rgba(255,255,255,0.14) !important;
        border-radius: 14px !important;
        color: #e5e7eb !important;
    }}
    div[role="listbox"] {{
        background: rgba(15, 18, 30, 0.98) !important;
        border: 1px solid rgba(255,255,255,0.14) !important;
        border-radius: 14px !important;
        box-shadow: 0 25px 55px rgba(0,0,0,0.55) !important;
    }}
    div[role="option"] {{
        color: #e5e7eb !important;
        background: transparent !important;
    }}
    div[role="option"]:hover {{
        background: rgba(168, 85, 247, 0.18) !important;
    }}

    /* ======================================================
       FIX: FILE UPLOADER (this is your current white box)
       ====================================================== */

    /* main uploader container */
    [data-testid="stFileUploader"] section {{
        background: rgba(255,255,255,0.08) !important;
        border: 1px dashed rgba(255,255,255,0.22) !important;
        border-radius: 16px !important;
        padding: 14px !important;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }}

    /* drag & drop text */
    [data-testid="stFileUploader"] * {{
        color: #e5e7eb !important;
    }}

    /* Browse files button inside uploader */
    [data-testid="stFileUploader"] button {{
        border-radius: 999px !important;
        border: 1px solid rgba(255,255,255,0.18) !important;
        background: linear-gradient(135deg, #a855f7, #3b82f6) !important;
        color: #ffffff !important;
        font-weight: 700 !important;
    }}

    /* When file uploaded list appears */
    [data-testid="stFileUploader"] ul {{
        background: rgba(0,0,0,0.20) !important;
        border: 1px solid rgba(255,255,255,0.12) !important;
        border-radius: 14px !important;
        padding: 10px !important;
    }}

    hr {{
        border: none;
        height: 1px;
        background: rgba(255,255,255,0.14);
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

# =========================================================
# 2. Helper functions
# =========================================================
def build_feature_vector_from_ui(
    dependents,
    referrals,
    tenure_months,
    monthly_charge,
    total_long_distance,
    total_revenue,
    total_services,
    married,
    internet_type,
    online_security,
    tech_support,
    offer,
    contract_type,
    pay_credit_card,
):
    total_charges = monthly_charge * tenure_months
    tenure_monthly_charge = monthly_charge * max(tenure_months, 1)
    referrals_tenure = referrals / max(tenure_months, 1)

    married_yes = 1 if married == "Yes" else 0

    if internet_type == "No internet":
        internet_service_yes = 0
        internet_type_fiber = 0
        internet_type_none = 1
    elif internet_type == "Fiber optic":
        internet_service_yes = 1
        internet_type_fiber = 1
        internet_type_none = 0
    else:
        internet_service_yes = 1
        internet_type_fiber = 0
        internet_type_none = 0

    online_security_yes = 1 if online_security == "Yes" else 0
    tech_support_yes = 1 if tech_support == "Yes" else 0
    offer_e = 1 if offer == "Offer E" else 0

    if contract_type == "Month-to-month":
        contract_one_year = 0
        contract_two_year = 0
    elif contract_type == "One year":
        contract_one_year = 1
        contract_two_year = 0
    else:
        contract_one_year = 0
        contract_two_year = 1

    payment_credit_card = 1 if pay_credit_card == "Credit card" else 0

    fv = {
        "Number_of_Dependents": dependents,
        "Number_of_Referrals": referrals,
        "Tenure_in_Months": tenure_months,
        "Monthly_Charge": monthly_charge,
        "Total_Charges": total_charges,
        "Total_Long_Distance_Charges": total_long_distance,
        "Total_Revenue": total_revenue,
        "Tenure_Monthly_Charge": tenure_monthly_charge,
        "Referrals_Tenure": referrals_tenure,
        "Married_Yes": married_yes,
        "Internet_Service_Yes": internet_service_yes,
        "Internet_Type_Fiber_Optic": internet_type_fiber,
        "Internet_Type_None": internet_type_none,
        "Online_Security_Yes": online_security_yes,
        "Premium_Tech_Support_Yes": tech_support_yes,
        "Offer_Offer_E": offer_e,
        "Contract_Two_Year": contract_two_year,
        "Contract_One_Year": contract_one_year,
        "Payment_Method_Credit_Card": payment_credit_card,
        "Total_Services": total_services,
    }
    return {col: fv[col] for col in feature_names}

def predict_single_customer(feature_dict):
    X_one = pd.DataFrame([feature_dict], columns=feature_names)
    proba = model.predict_proba(X_one)[0]
    predicted_class_idx = int(np.argmax(proba))
    predicted_class = label_encoder.classes_[predicted_class_idx]
    churn_proba = float(proba[churn_idx])
    churn_risk_flag = churn_proba >= churn_threshold
    return proba, predicted_class, churn_proba, churn_risk_flag

# =========================================================
# 3. App Header
# =========================================================
st.title("Customer Churn Prediction App")
st.markdown(
    "<div style='margin-top:-8px; margin-bottom:18px; color:rgba(229,231,235,0.80);'>"
    "Predict churn risk and explore churn drivers with interactive visuals."
    "</div>",
    unsafe_allow_html=True,
)

# =========================================================
# 4. PAGE NAVIGATION
# =========================================================
page = st.sidebar.radio("Navigation", ["Prediction", "Descriptive Analysis"])

# =========================================================
# PAGE 1: PREDICTION
# =========================================================
if page == "Prediction":
    st.subheader("Predict churn for a single customer")

    col1, col2, col3 = st.columns(3)
    with col1:
        dependents = st.slider("Number of dependents", 0, 5, 0)
        referrals = st.slider("Number of referrals", 0, 10, 0)
    with col2:
        tenure_months = st.slider("Tenure (months)", 0, 72, 12)
        total_services = st.slider("Number of services", 1, 10, 3)
    with col3:
        married = st.radio("Married", ["No", "Yes"], horizontal=True)

    st.markdown("### Internet & services")
    col4, col5, col6 = st.columns(3)
    with col4:
        internet_type = st.selectbox("Internet type", ["DSL / Other", "Fiber optic", "No internet"])
    with col5:
        online_security = st.radio("Online security", ["No", "Yes"], horizontal=True)
    with col6:
        tech_support = st.radio("Premium tech support", ["No", "Yes"], horizontal=True)

    st.markdown("### Billing & contract")
    col7, col8, col9 = st.columns(3)
    with col7:
        monthly_charge = st.number_input("Monthly charge", 0.0, 500.0, 70.0, 1.0)
        total_long_distance = st.number_input("Total long distance charges", 0.0, 1000.0, 50.0, 1.0)
    with col8:
        total_revenue = st.number_input("Total revenue to date", 0.0, 10000.0, 2000.0, 10.0)
        contract_type = st.selectbox("Contract type", ["Month-to-month", "One year", "Two year"])
    with col9:
        offer = st.selectbox("Current offer", ["No special offer", "Offer E"])
        pay_credit_card = st.selectbox("Payment method", ["Other", "Credit card"])

    st.markdown("---")

    if st.button("Predict churn risk"):
        fv = build_feature_vector_from_ui(
            dependents=dependents,
            referrals=referrals,
            tenure_months=tenure_months,
            monthly_charge=monthly_charge,
            total_long_distance=total_long_distance,
            total_revenue=total_revenue,
            total_services=total_services,
            married=married,
            internet_type=internet_type,
            online_security=online_security,
            tech_support=tech_support,
            offer=offer,
            contract_type=contract_type,
            pay_credit_card=pay_credit_card,
        )

        proba, pred_class, churn_proba, churn_risk_flag = predict_single_customer(fv)

        st.markdown("### Prediction result")
        k1, k2, k3 = st.columns(3)

        with k1:
            st.markdown(
                f"""<div class="metric-card"><h4>Predicted segment</h4><h2>{pred_class}</h2></div>""",
                unsafe_allow_html=True,
            )

        with k2:
            st.markdown(
                f"""<div class="metric-card"><h4>Churn probability</h4><h2>{churn_proba:.3f}</h2>
                <p style="color:rgba(229,231,235,0.75); margin:0.4rem 0 0 0;">Threshold: {churn_threshold:.2f}</p></div>""",
                unsafe_allow_html=True,
            )

        with k3:
            risk_label = "HIGH risk" if churn_risk_flag else "Normal risk"
            risk_color = "#fca5a5" if churn_risk_flag else "#86efac"
            st.markdown(
                f"""<div class="metric-card"><h4>Risk level</h4>
                <h2 style="color:{risk_color};">{risk_label}</h2></div>""",
                unsafe_allow_html=True,
            )

        if churn_risk_flag:
            st.error("This customer is flagged as **HIGH churn risk**.")
        else:
            st.success("This customer is **not flagged** as high churn risk.")

        st.markdown("#### Class probability breakdown")
        proba_df = pd.DataFrame({"Class": label_encoder.classes_, "Probability": proba})

        chart = alt.Chart(proba_df).mark_bar().encode(
            x=alt.X("Class", sort=None),
            y=alt.Y("Probability", scale=alt.Scale(domain=[0, 1])),
            color=alt.Color("Class", legend=None),
            tooltip=["Class", alt.Tooltip("Probability", format=".3f")],
        )
        st.altair_chart(chart, use_container_width=True)

# =========================================================
# PAGE 2: DESCRIPTIVE ANALYSIS  (Improved: WHY customers leave)  ✅ Altair v6 safe
# =========================================================
else:
    st.subheader("Descriptive Analysis (Why Customers Leave)")

    st.write(
        """
        Upload the **original churn dataset CSV** that contains:
        **Customer Status**, **Churn Category**, and **Churn Reason**.

        This page focuses on **WHY customers churned** (Category + Reason) and
        **which segments churn more** (Contract / Internet Type / Offer etc.).
        """
    )

    data_file = st.file_uploader("Upload dataset for descriptive analysis", type=["csv"])

    if data_file is None:
        st.info("Upload a CSV to view churn drivers (Category + Reason) and churn breakdown charts.")
    else:
        raw_df = pd.read_csv(data_file)

        required_cols = ["Customer Status", "Churn Category", "Churn Reason"]
        missing_cols = [c for c in required_cols if c not in raw_df.columns]
        if missing_cols:
            st.error(f"Missing required columns: {missing_cols}")
            st.write("Your descriptive analysis needs these columns exactly:")
            st.code(required_cols)
            st.stop()

        # ------------------------------
        # KPIs (quick business snapshot)
        # ------------------------------
        total_customers = len(raw_df)
        churned_df = raw_df[
            raw_df["Customer Status"].astype(str).str.strip().str.lower() == "churned"
        ].copy()
        churned_count = len(churned_df)
        churn_rate = churned_count / total_customers if total_customers else 0

        st.markdown("### Key KPIs")
        k1, k2, k3 = st.columns(3)
        with k1:
            st.markdown(
                f"""<div class="metric-card"><h4>Total customers</h4><h2>{total_customers:,}</h2></div>""",
                unsafe_allow_html=True,
            )
        with k2:
            st.markdown(
                f"""<div class="metric-card"><h4>Churned customers</h4><h2>{churned_count:,}</h2></div>""",
                unsafe_allow_html=True,
            )
        with k3:
            st.markdown(
                f"""<div class="metric-card"><h4>Overall churn rate</h4><h2>{churn_rate:.1%}</h2></div>""",
                unsafe_allow_html=True,
            )

        st.markdown("---")

        # =========================================================
        # 1) WHY customers leave (CHURN CATEGORY)
        # =========================================================
        st.markdown("## 1) Churn Categories (Why customers leave)")

        if churned_count == 0:
            st.warning("No rows found where Customer Status == 'Churned'. Cannot compute churn categories/reasons.")
            st.stop()

        churned_df["Churn Category"] = churned_df["Churn Category"].fillna("Unknown").astype(str).str.strip()
        churned_df["Churn Reason"] = churned_df["Churn Reason"].fillna("Unknown").astype(str).str.strip()

        # Altair-safe column names (no spaces)
        cat_counts = (
            churned_df["Churn Category"]
            .value_counts()
            .rename_axis("Churn_Category")
            .reset_index(name="Count")
        )
        cat_counts["Percent"] = (cat_counts["Count"] / cat_counts["Count"].sum()) * 100

        colA, colB = st.columns(2)

        with colA:
            st.markdown("### Category distribution (bar)")
            cat_bar = alt.Chart(cat_counts).mark_bar().encode(
                x=alt.X("Churn_Category:N", sort="-y", title="Churn Category"),
                y=alt.Y("Count:Q", title="Number of churned customers"),
                tooltip=[
                    alt.Tooltip("Churn_Category:N", title="Category"),
                    alt.Tooltip("Count:Q", title="Count"),
                    alt.Tooltip("Percent:Q", title="Percent", format=".1f"),
                ],
            )
            st.altair_chart(cat_bar, use_container_width=True)

        with colB:
            st.markdown("### Category share (%)")
            cat_pie = alt.Chart(cat_counts).mark_arc(innerRadius=60).encode(
                theta=alt.Theta("Count:Q"),
                color=alt.Color("Churn_Category:N", legend=alt.Legend(title="Churn Category")),
                tooltip=[
                    alt.Tooltip("Churn_Category:N", title="Category"),
                    alt.Tooltip("Percent:Q", title="Percent", format=".1f"),
                    alt.Tooltip("Count:Q", title="Count"),
                ],
            )
            st.altair_chart(cat_pie, use_container_width=True)

        st.dataframe(cat_counts, use_container_width=True)

        st.markdown("---")

        # =========================================================
        # 2) TOP CHURN REASONS (inside each category)
        # =========================================================
        st.markdown("## 2) Top Churn Reasons (What exactly made them leave)")

        category_list = ["All"] + sorted(cat_counts["Churn_Category"].unique().tolist())
        selected_cat = st.selectbox("Filter by churn category", category_list)

        top_n = st.slider("Top N churn reasons to display", 5, 20, 10)

        if selected_cat != "All":
            reason_df = churned_df[churned_df["Churn Category"] == selected_cat].copy()
        else:
            reason_df = churned_df.copy()

        reason_counts = (
            reason_df["Churn Reason"]
            .value_counts()
            .head(top_n)
            .rename_axis("Churn_Reason")
            .reset_index(name="Count")
        )

        if reason_counts.empty:
            st.warning("No churn reasons found for the selected category.")
        else:
            reason_bar = alt.Chart(reason_counts).mark_bar().encode(
                y=alt.Y("Churn_Reason:N", sort="-x", title="Churn Reason"),
                x=alt.X("Count:Q", title="Number of churned customers"),
                tooltip=[
                    alt.Tooltip("Churn_Reason:N", title="Reason"),
                    alt.Tooltip("Count:Q", title="Count"),
                ],
            )
            st.altair_chart(reason_bar, use_container_width=True)
            st.dataframe(reason_counts, use_container_width=True)

        st.markdown("---")

        # =========================================================
        # 3) Churn Drivers (segment-level churn rate)
        # =========================================================
        st.markdown("## 3) Churn Drivers by Customer Segment")

        st.write(
            "This shows **which groups churn more (churn rate)**. "
            "It helps explain churn beyond raw counts (e.g., Month-to-Month vs Two-Year)."
        )

        candidate_cols = [
            "Contract",
            "Internet Type",
            "Offer",
            "Payment Method",
            "Internet Service",
            "Married",
            "Gender",
        ]
        existing_driver_cols = [c for c in candidate_cols if c in raw_df.columns]

        if not existing_driver_cols:
            st.info(
                "Driver charts not shown because the dataset does not include common segmentation columns "
                "(e.g., Contract, Internet Type, Offer, Payment Method)."
            )
        else:
            driver_col = st.selectbox("Choose a driver column", existing_driver_cols)

            temp = raw_df.copy()
            temp[driver_col] = temp[driver_col].fillna("Unknown").astype(str).str.strip()
            temp["__is_churned__"] = (
                temp["Customer Status"].astype(str).str.strip().str.lower() == "churned"
            ).astype(int)

            # Altair-safe metrics columns
            driver_stats = (
                temp.groupby(driver_col)["__is_churned__"]
                .agg(total_customers="count", churned_customers="sum")
                .reset_index()
            )
            driver_stats["churn_rate"] = driver_stats["churned_customers"] / driver_stats["total_customers"]
            driver_stats = driver_stats.sort_values("churn_rate", ascending=False)

            churn_rate_bar = alt.Chart(driver_stats).mark_bar().encode(
                y=alt.Y(f"{driver_col}:N", sort="-x", title=driver_col),
                x=alt.X("churn_rate:Q", axis=alt.Axis(format="%"), title="Churn Rate"),
                tooltip=[
                    alt.Tooltip(f"{driver_col}:N", title=driver_col),
                    alt.Tooltip("total_customers:Q", title="Total Customers"),
                    alt.Tooltip("churned_customers:Q", title="Churned Customers"),
                    alt.Tooltip("churn_rate:Q", title="Churn Rate", format=".1%"),
                ],
            )
            st.altair_chart(churn_rate_bar, use_container_width=True)

            st.dataframe(driver_stats, use_container_width=True)

        st.markdown("---")

        # =========================================================
        # 4) Quick preview (optional)
        # =========================================================
        with st.expander("Preview uploaded dataset"):
            st.dataframe(raw_df.head(30), use_container_width=True)
